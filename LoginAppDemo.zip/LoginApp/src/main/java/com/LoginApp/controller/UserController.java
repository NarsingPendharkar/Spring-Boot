package com.LoginApp.controller;

import com.LoginApp.Repository.UserRepository;
import com.LoginApp.entity.Userdata;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class UserController {
    @Autowired
    private UserRepository userRepository;

    // open loign page for user
    @GetMapping("/")
    public String home(){
        return "index";
    }


    //get register from for new user
    @GetMapping("/reg")
    public String reg(){
        return "Register";
    }
    //save data in database after registration
    @PostMapping("/register")
    public String register(@ModelAttribute Userdata userdata){
        userRepository.save(userdata);
        return "Success";
    }
    //method to validate user pass and login in page
    @GetMapping("/valid")
    public String loginvalidate(@RequestParam String username , @RequestParam String password , Model model){
        Userdata user=userRepository.findByUsername(username);
        if(user!=null && user.getPassword().equals(password)&&user.getUsername().equals(username)){

            model.addAttribute("userdata",user);
            System.out.println(user.getPassword());
            System.out.println(user.getUsername());
            return "Success";
        }else {
            return "redirect:/";
        }

    }


}
