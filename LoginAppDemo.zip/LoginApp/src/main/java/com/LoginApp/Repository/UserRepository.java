package com.LoginApp.Repository;

import com.LoginApp.entity.Userdata;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface UserRepository extends JpaRepository<Userdata,Integer> {
    Userdata findByUsername(String uname);
}
